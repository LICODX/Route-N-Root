package main

import (
        "crypto/ecdsa"
        "crypto/elliptic"
        "crypto/rand"
        "flag"
        "fmt"
        "log"
        "math/big"
        "os"

        "rnr-blockchain/pkg/genesis"
        "rnr-blockchain/pkg/wallet"
)

func main() {
        initCmd := flag.NewFlagSet("init", flag.ExitOnError)
        chainID := initCmd.String("chain-id", "rnr-mainnet-1", "Chain ID")
        networkName := initCmd.String("network", "RNR Mainnet", "Network name")
        outputFile := initCmd.String("output", "genesis.json", "Output genesis config file")
        validatorCount := initCmd.Int("validators", 1, "Number of genesis validators")
        walletPassword := initCmd.String("password", "", "Wallet password (required)")

        if len(os.Args) < 2 {
                fmt.Println("RNR Genesis Tool")
                fmt.Println("\nUsage:")
                fmt.Println("  genesis init [flags]    - Initialize genesis configuration")
                fmt.Println("\nFlags:")
                initCmd.PrintDefaults()
                os.Exit(1)
        }

        switch os.Args[1] {
        case "init":
                initCmd.Parse(os.Args[2:])
                
                if *walletPassword == "" {
                        log.Fatal("❌ Password is required (use -password flag)")
                }

                config := genesis.DefaultGenesisConfig()
                config.ChainID = *chainID
                config.NetworkName = *networkName

                fmt.Println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                fmt.Println("🔐 RNR Genesis Initialization")
                fmt.Printf("   Chain ID: %s\n", config.ChainID)
                fmt.Printf("   Network: %s\n", config.NetworkName)
                fmt.Println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")

                os.MkdirAll("./genesis-keys", 0700)

                for i := 0; i < *validatorCount; i++ {
                        fmt.Printf("📝 Creating validator #%d...\n", i+1)

                        mnemonic, err := wallet.GenerateMnemonic()
                        if err != nil {
                                log.Fatalf("❌ Failed to generate mnemonic: %v", err)
                        }

                        w, err := wallet.NewWalletFromMnemonic(mnemonic)
                        if err != nil {
                                log.Fatalf("❌ Failed to create wallet: %v", err)
                        }

                        validatorKey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
                        if err != nil {
                                log.Fatalf("❌ Failed to generate validator key: %v", err)
                        }

                        walletFile := fmt.Sprintf("./genesis-keys/validator-%d-wallet.json", i+1)
                        if err := wallet.SaveWalletToFile(w, *walletPassword, walletFile); err != nil {
                                log.Fatalf("❌ Failed to save wallet: %v", err)
                        }

                        mnemonicFile := fmt.Sprintf("./genesis-keys/validator-%d-mnemonic.txt", i+1)
                        if err := os.WriteFile(mnemonicFile, []byte(mnemonic), 0600); err != nil {
                                log.Fatalf("❌ Failed to save mnemonic: %v", err)
                        }

                        stake := new(big.Int).Mul(big.NewInt(1000), big.NewInt(1e18))
                        if err := config.AddValidator(w.Address, &validatorKey.PublicKey, stake); err != nil {
                                log.Fatalf("❌ Failed to add validator: %v", err)
                        }

                        if i == 0 {
                                config.GenesisWallet = w.Address
                        }

                        fmt.Printf("   ✅ Validator #%d created\n", i+1)
                        fmt.Printf("      Address: %s\n", w.Address)
                        fmt.Printf("      Wallet: %s\n", walletFile)
                        fmt.Printf("      Mnemonic: %s\n", mnemonicFile)
                        fmt.Printf("      Stake: %s RNR\n\n", stake.String())
                }

                if err := config.Validate(); err != nil {
                        log.Fatalf("❌ Genesis config validation failed: %v", err)
                }

                if err := config.Save(*outputFile); err != nil {
                        log.Fatalf("❌ Failed to save genesis config: %v", err)
                }

                genesisBlock := config.CreateGenesisBlock()
                blockHash, _ := genesisBlock.Hash()

                fmt.Println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                fmt.Println("✅ Genesis Configuration Created Successfully!")
                fmt.Printf("   📁 Config File: %s\n", *outputFile)
                fmt.Printf("   🔑 Keys Directory: ./genesis-keys/\n")
                fmt.Printf("   💼 Genesis Wallet: %s\n", config.GenesisWallet)
                fmt.Printf("   👥 Total Validators: %d\n", len(config.InitialValidators))
                fmt.Printf("   🔗 Genesis Block Hash: %x\n", blockHash[:16])
                fmt.Println("\n⚠️  IMPORTANT: Backup ./genesis-keys/ directory securely!")
                fmt.Println("   This contains all validator private keys and mnemonics.")
                fmt.Println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

        default:
                fmt.Printf("Unknown command: %s\n", os.Args[1])
                os.Exit(1)
        }
}
