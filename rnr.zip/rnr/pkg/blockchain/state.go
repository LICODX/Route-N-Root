package blockchain

import (
        "encoding/json"
        "fmt"
        "log"
        "math/big"
        "sort"
        "sync"
        "time"

        "github.com/syndtr/goleveldb/leveldb"
        "rnr-blockchain/pkg/core"
)

type State struct {
        db            *leveldb.DB
        accounts      map[string]*core.Account
        validators    map[string]*core.ValidatorInfo
        transactions  map[string]*core.Transaction
        mu            sync.RWMutex
        lastBlockHash []byte
}

// GetDB returns the underlying LevelDB instance
func (s *State) GetDB() *leveldb.DB {
        return s.db
}

func NewState(db *leveldb.DB) (*State, error) {
        state := &State{
                db:           db,
                accounts:     make(map[string]*core.Account),
                validators:   make(map[string]*core.ValidatorInfo),
                transactions: make(map[string]*core.Transaction),
        }

        iter := db.NewIterator(nil, nil)
        for iter.Next() {
                key := iter.Key()
                value := iter.Value()
                if len(key) > 8 && string(key[:8]) == "account_" {
                        var account core.Account
                        if err := json.Unmarshal(value, &account); err != nil {
                                iter.Release()
                                return nil, err
                        }
                        state.accounts[string(key[8:])] = &account
                }
        }
        iter.Release()

        iter = db.NewIterator(nil, nil)
        for iter.Next() {
                key := iter.Key()
                value := iter.Value()
                if len(key) > 10 && string(key[:10]) == "validator_" {
                        var validator core.ValidatorInfo
                        if err := json.Unmarshal(value, &validator); err != nil {
                                iter.Release()
                                return nil, err
                        }
                        state.validators[string(key[10:])] = &validator
                }
        }
        iter.Release()

        lastBlockHash, err := db.Get([]byte("last_block_hash"), nil)
        if err != nil {
                lastBlockHash = []byte{}
                if err := db.Put([]byte("last_block_hash"), lastBlockHash, nil); err != nil {
                        return nil, err
                }
        }
        state.lastBlockHash = lastBlockHash

        return state, nil
}

func (s *State) UpdateAccount(account *core.Account) {
        s.mu.Lock()
        defer s.mu.Unlock()
        s.accounts[account.Address] = account
        accountBytes, err := json.Marshal(account)
        if err != nil {
                log.Printf("Failed to marshal account: %v", err)
                return
        }
        if err := s.db.Put([]byte("account_"+account.Address), accountBytes, nil); err != nil {
                log.Printf("Failed to save account: %v", err)
        }
}

func (s *State) GetAccount(address string) (*core.Account, error) {
        s.mu.RLock()
        defer s.mu.RUnlock()
        account, ok := s.accounts[address]
        if !ok {
                return &core.Account{
                        Address: address,
                        Balance: big.NewInt(0),
                        Nonce:   0,
                }, nil
        }
        return account, nil
}

func (s *State) AccountExists(address string) bool {
        s.mu.RLock()
        defer s.mu.RUnlock()
        _, exists := s.accounts[address]
        return exists
}

func (s *State) UpdateValidator(validator *core.ValidatorInfo) {
        s.mu.Lock()
        defer s.mu.Unlock()
        s.validators[validator.ID] = validator
        validatorBytes, err := json.Marshal(validator)
        if err != nil {
                log.Printf("Failed to marshal validator: %v", err)
                return
        }
        if err := s.db.Put([]byte("validator_"+validator.ID), validatorBytes, nil); err != nil {
                log.Printf("Failed to save validator: %v", err)
        }
}

func (s *State) GetValidator(id string) (*core.ValidatorInfo, error) {
        s.mu.RLock()
        defer s.mu.RUnlock()
        validator, ok := s.validators[id]
        if !ok {
                return nil, fmt.Errorf("validator not found: %s", id)
        }
        return validator, nil
}

func (s *State) GetValidators() map[string]*core.ValidatorInfo {
        s.mu.RLock()
        defer s.mu.RUnlock()
        return s.validators
}

func (s *State) GetActiveValidators() []string {
        s.mu.RLock()
        defer s.mu.RUnlock()
        validators := make([]string, 0, len(s.validators))
        for id, v := range s.validators {
                if v.IsActive {
                        validators = append(validators, id)
                }
        }
        // CRITICAL FIX: Sort untuk deterministic ordering
        // Map iteration di Go tidak deterministik, bisa cause fork!
        // Dengan sort, semua node akan dapat urutan validator yang sama
        sort.Strings(validators)
        return validators
}

func (s *State) CreateGenesisValidator(id string, pubKey []byte) {
        validator := &core.ValidatorInfo{
                ID:                id,
                PublicKey:         pubKey,
                PoBScore:          1.0,
                Reputation:        100,
                LastPoBTest:       time.Now(),
                IsActive:          true,
                RewardAddress:     id,
                NetworkASN:        "local",
                IPAddress:         "127.0.0.1",
                IsObserver:        false,
                ObserverStartTime: time.Time{},
                ObserverDuration:  0,
        }
        s.UpdateValidator(validator)
}
