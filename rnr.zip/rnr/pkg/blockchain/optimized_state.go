package blockchain

import (
        "encoding/json"
        "fmt"
        "log"
        "math/big"
        "sync"

        "github.com/syndtr/goleveldb/leveldb"
        "github.com/syndtr/goleveldb/leveldb/opt"
        "github.com/syndtr/goleveldb/leveldb/util"
        "rnr-blockchain/pkg/core"
)

type OptimizedState struct {
        db              *leveldb.DB
        accounts        sync.Map
        validators      sync.Map
        transactions    sync.Map
        lastBlockHash   []byte
        mu              sync.RWMutex
        writeBatch      *leveldb.Batch
        batchSize       int
        maxBatchSize    int
}

func NewOptimizedState(db *leveldb.DB) (*OptimizedState, error) {
        state := &OptimizedState{
                db:           db,
                writeBatch:   new(leveldb.Batch),
                maxBatchSize: 100,
        }
        
        if err := state.loadAccounts(); err != nil {
                return nil, fmt.Errorf("failed to load accounts: %w", err)
        }
        
        if err := state.loadValidators(); err != nil {
                return nil, fmt.Errorf("failed to load validators: %w", err)
        }
        
        lastBlockHash, err := db.Get([]byte("last_block_hash"), nil)
        if err != nil {
                lastBlockHash = []byte{}
                if err := db.Put([]byte("last_block_hash"), lastBlockHash, nil); err != nil {
                        return nil, err
                }
        }
        state.lastBlockHash = lastBlockHash
        
        return state, nil
}

func (s *OptimizedState) loadAccounts() error {
        iter := s.db.NewIterator(util.BytesPrefix([]byte("account_")), nil)
        defer iter.Release()
        
        for iter.Next() {
                key := iter.Key()
                value := iter.Value()
                
                var account core.Account
                if err := json.Unmarshal(value, &account); err != nil {
                        return err
                }
                
                address := string(key[8:])
                s.accounts.Store(address, &account)
        }
        
        return iter.Error()
}

func (s *OptimizedState) loadValidators() error {
        iter := s.db.NewIterator(util.BytesPrefix([]byte("validator_")), nil)
        defer iter.Release()
        
        for iter.Next() {
                key := iter.Key()
                value := iter.Value()
                
                var validator core.ValidatorInfo
                if err := json.Unmarshal(value, &validator); err != nil {
                        return err
                }
                
                validatorID := string(key[10:])
                s.validators.Store(validatorID, &validator)
        }
        
        return iter.Error()
}

func (s *OptimizedState) UpdateAccountBatch(account *core.Account) error {
        s.accounts.Store(account.Address, account)
        
        accountBytes, err := json.Marshal(account)
        if err != nil {
                return fmt.Errorf("failed to marshal account: %w", err)
        }
        
        s.mu.Lock()
        s.writeBatch.Put([]byte("account_"+account.Address), accountBytes)
        s.batchSize++
        
        if s.batchSize >= s.maxBatchSize {
                if err := s.FlushBatch(); err != nil {
                        s.mu.Unlock()
                        return err
                }
        }
        s.mu.Unlock()
        
        return nil
}

func (s *OptimizedState) UpdateValidatorBatch(validator *core.ValidatorInfo) error {
        s.validators.Store(validator.ID, validator)
        
        validatorBytes, err := json.Marshal(validator)
        if err != nil {
                return fmt.Errorf("failed to marshal validator: %w", err)
        }
        
        s.mu.Lock()
        s.writeBatch.Put([]byte("validator_"+validator.ID), validatorBytes)
        s.batchSize++
        
        if s.batchSize >= s.maxBatchSize {
                if err := s.FlushBatch(); err != nil {
                        s.mu.Unlock()
                        return err
                }
        }
        s.mu.Unlock()
        
        return nil
}

func (s *OptimizedState) FlushBatch() error {
        if s.batchSize == 0 {
                return nil
        }
        
        writeOpts := &opt.WriteOptions{
                Sync: false,
        }
        
        if err := s.db.Write(s.writeBatch, writeOpts); err != nil {
                return fmt.Errorf("failed to flush batch: %w", err)
        }
        
        s.writeBatch.Reset()
        s.batchSize = 0
        
        return nil
}

func (s *OptimizedState) GetAccount(address string) (*core.Account, error) {
        if val, ok := s.accounts.Load(address); ok {
                return val.(*core.Account), nil
        }
        
        return &core.Account{
                Address: address,
                Balance: big.NewInt(0),
                Nonce:   0,
        }, nil
}

func (s *OptimizedState) AccountExists(address string) bool {
        _, exists := s.accounts.Load(address)
        return exists
}

func (s *OptimizedState) GetValidator(id string) (*core.ValidatorInfo, error) {
        if val, ok := s.validators.Load(id); ok {
                return val.(*core.ValidatorInfo), nil
        }
        
        return nil, fmt.Errorf("validator not found: %s", id)
}

func (s *OptimizedState) GetValidators() []*core.ValidatorInfo {
        validators := make([]*core.ValidatorInfo, 0)
        
        s.validators.Range(func(key, value interface{}) bool {
                if v, ok := value.(*core.ValidatorInfo); ok {
                        validators = append(validators, v)
                }
                return true
        })
        
        return validators
}

func (s *OptimizedState) ApplyTransaction(tx *core.Transaction) error {
        sender, err := s.GetAccount(tx.From)
        if err != nil {
                return err
        }
        
        if sender.Balance.Cmp(tx.Amount) < 0 {
                return fmt.Errorf("insufficient balance")
        }
        
        if sender.Nonce != tx.Nonce {
                return fmt.Errorf("invalid nonce")
        }
        
        sender.Balance = sender.Balance.Sub(sender.Balance, tx.Amount)
        sender.Nonce++
        
        if err := s.UpdateAccountBatch(sender); err != nil {
                return err
        }
        
        recipient, err := s.GetAccount(tx.To)
        if err != nil {
                return err
        }
        
        recipient.Balance = recipient.Balance.Add(recipient.Balance, tx.Amount)
        
        if err := s.UpdateAccountBatch(recipient); err != nil {
                return err
        }
        
        return nil
}

func (s *OptimizedState) SaveTransaction(tx *core.Transaction) {
        s.transactions.Store(tx.ID, tx)
        
        txBytes, err := json.Marshal(tx)
        if err != nil {
                log.Printf("Failed to marshal transaction: %v", err)
                return
        }
        
        s.mu.Lock()
        s.writeBatch.Put([]byte("tx_"+tx.ID), txBytes)
        s.batchSize++
        
        if s.batchSize >= s.maxBatchSize {
                s.FlushBatch()
        }
        s.mu.Unlock()
}

func (s *OptimizedState) Close() error {
        s.mu.Lock()
        defer s.mu.Unlock()
        
        return s.FlushBatch()
}
